# Zujaj Cast · زجاج كاست

Free, ad-free Android app: browse the web, detect the video on the page and cast it to your TV, or mirror your phone screen with a quality of your choice. Black + muted red (or blue) glass interface. Arabic and English.

تطبيق أندرويد مجاني وبلا إعلانات: تصفّح، يكتشف الفيديو في الصفحة ويبثّه إلى التلفاز، أو يبثّ شاشة هاتفك بجودة تختارها. واجهة زجاجية بالأسود والأحمر الخافت (أو الأزرق). عربي وإنجليزي.

## Build the APK with GitHub (no Android Studio needed)

1. Create a new GitHub repository and upload everything in this folder (keep `.github/workflows/android.yml`).
2. Open the **Actions** tab, run **Build Android APK** (it also runs on every push).
3. When it finishes, download `zujaj-cast-debug-apk` from the run page, unzip and install the `.apk` on your phone.

## What works

| Feature | How | Status |
| --- | --- | --- |
| Browser with video detection | WebView; sniffs mp4/m3u8/mpd/webm requests + `<video>` tags | written, untested on device |
| Ad / pop-up blocking | host blocklist in `web/AdBlocker.kt` | written |
| Cast to Chromecast | Google Cast SDK, default receiver | written, untested; needs Google Play Services |
| Cast to DLNA / UPnP TVs | SSDP discovery + AVTransport (Samsung, LG, Sony, many others) | written, untested |
| Cast to Roku | ECP | experimental |
| Cast local video/audio/photo | built-in HTTP server with Range | written, untested |
| Screen mirroring + quality presets | MediaProjection -> H.264 -> MPEG-TS over HTTP to a DLNA TV | MPEG-TS packetizer verified (see below); end-to-end untested |
| Chromecast screen mirroring | button that opens Android's own "Cast" screen | works through the system |
| Bookmarks, history, home page | local only | written |

Quality presets: 480p/30 (1.8 Mbps), 720p/30 (4.5 Mbps), 1080p/30 (9 Mbps), 1080p/60 (15 Mbps). Edit them in `mirror/MirrorStreamer.kt`.

## Known limits (be honest with your users)

- This code was written without an Android SDK available, so it has **never been compiled or run on a phone**. Expect to fix a few compile errors on the first Actions run. The MPEG-TS muxer logic was checked separately (a Python port of it produced a stream that ffprobe/ffmpeg decode with 120/120 frames).
- Mirroring is video only (no audio yet). Many TVs add 1 to 3 seconds of delay on a live stream.
- DRM services (Netflix, Disney+, etc.) cannot be cast, same as the original apps in this category.
- The glass look is simulated with translucent gradients; Compose cannot blur what is behind a view, so it is not a true backdrop blur.
- Debug APK only. For Google Play you need your own signing key and a different app name/icon than any other cast app.

## Layout

```
replica/            recon map and feature matrix of the app this was inspired by
app/src/main/java/dz/zujaj/cast/
  cast/             CastManager, DLNA, Roku, Chromecast options
  net/              SSDP discovery, Http helper, MediaServer (files + live stream)
  mirror/           MirrorService, MirrorStreamer, TsMuxer, LiveHub
  web/              AdBlocker, MediaSniffer
  ui/               glass components, screens
```

Inspired by the feature set of Web Video Cast. No code, name, logo, text or images were taken from it.

MIT license.

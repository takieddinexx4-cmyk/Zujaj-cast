package dz.zujaj.cast.mirror

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.util.DisplayMetrics
import android.view.Surface
import android.view.WindowManager

enum class Quality(val shortSide: Int, val fps: Int, val bitrate: Int) {
    SAVER(480, 30, 1_800_000),
    BALANCED(720, 30, 4_500_000),
    HIGH(1080, 30, 9_000_000),
    ULTRA(1080, 60, 15_000_000)
}

/** Screen -> VirtualDisplay -> H.264 hardware encoder -> MPEG-TS -> [LiveHub]. */
class MirrorStreamer(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val quality: Quality,
    private val hub: LiveHub
) {
    @Volatile private var running = false
    private var codec: MediaCodec? = null
    private var surface: Surface? = null
    private var display: VirtualDisplay? = null
    private var thread: Thread? = null

    private fun even(v: Int) = v and 1.inv()

    @Suppress("DEPRECATION")
    fun start() {
        val dm = DisplayMetrics()
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val factor = minOf(1f, quality.shortSide.toFloat() / shortSide)
        val w = even((dm.widthPixels * factor).toInt())
        val h = even((dm.heightPixels * factor).toInt())

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, quality.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, quality.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
            // A still screen produces no new frames; repeat the last one so the TV never starves.
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L / quality.fps * 2)
        }
        val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val s = c.createInputSurface()
        c.start()
        codec = c
        surface = s
        display = projection.createVirtualDisplay(
            "zujaj-mirror", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, s, null, null
        )

        running = true
        thread = Thread({ pump(c) }, "zujaj-encoder").also { it.start() }
    }

    private fun pump(c: MediaCodec) {
        val mux = TsMuxer()
        val info = MediaCodec.BufferInfo()
        try {
            while (running) {
                val i = c.dequeueOutputBuffer(info, 100_000)
                if (i < 0) continue
                val buf = c.getOutputBuffer(i)
                if (buf != null && info.size > 0) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    val data = ByteArray(info.size)
                    buf.get(data)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        mux.setConfig(data)
                    } else {
                        val key = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                        hub.broadcast(mux.frame(data, info.presentationTimeUs, key), key)
                    }
                }
                c.releaseOutputBuffer(i, false)
            }
        } catch (_: Exception) {
            // encoder stopped underneath us
        }
    }

    fun stop() {
        running = false
        runCatching { thread?.join(500) }
        runCatching { display?.release() }
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        runCatching { surface?.release() }
        runCatching { projection.stop() }
        hub.close()
    }
}

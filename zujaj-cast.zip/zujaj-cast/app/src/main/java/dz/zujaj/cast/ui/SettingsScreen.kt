package dz.zujaj.cast.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dz.zujaj.cast.R
import dz.zujaj.cast.data.Store

@Composable
fun SettingsScreen(modifier: Modifier) {
    val accent = LocalAccent.current
    var adblock by remember { mutableStateOf(Store.adblock) }
    var home by remember { mutableStateOf(Store.home) }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(stringResource(R.string.theme), color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassChip(stringResource(R.string.theme_red), selected = Store.accentKey == "red") { Store.setAccent("red") }
            GlassChip(stringResource(R.string.theme_blue), selected = Store.accentKey == "blue") { Store.setAccent("blue") }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.adblock), color = Color.White, modifier = Modifier.weight(1f))
                Switch(
                    checked = adblock,
                    onCheckedChange = { adblock = it; Store.setAdblock(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = accent.main)
                )
            }
        }

        Text(stringResource(R.string.home_page), color = Color.White, fontWeight = FontWeight.Bold)
        GlassCard(Modifier.fillMaxWidth(), radius = 18.dp) {
            BasicTextField(
                value = home,
                onValueChange = { home = it },
                singleLine = true,
                textStyle = TextStyle(color = Color.White),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { Store.setHome(home.trim()) }),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )
        }

        Text(stringResource(R.string.about), color = Color.White.copy(alpha = 0.7f))
    }
}

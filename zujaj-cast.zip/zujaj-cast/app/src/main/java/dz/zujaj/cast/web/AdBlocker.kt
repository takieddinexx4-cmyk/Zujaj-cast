package dz.zujaj.cast.web

/** Host-based ad / tracker blocking for the in-app browser. Small on purpose; extend the list freely. */
object AdBlocker {
    private val hosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "pagead2.googlesyndication.com", "google-analytics.com", "googletagmanager.com",
        "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "propellerads.com", "exoclick.com",
        "juicyads.com", "trafficjunky.com", "adsterra.com", "popcash.net", "mgid.com", "revcontent.com",
        "criteo.com", "rubiconproject.com", "pubmatic.com", "openx.net", "amazon-adsystem.com",
        "moatads.com", "scorecardresearch.com", "adcolony.com", "unityads.unity3d.com", "applovin.com",
        "ads.yahoo.com", "advertising.com", "smartadserver.com", "casalemedia.com", "yieldmo.com",
        "onclickads.net", "clickadu.com", "hilltopads.net", "richpush.co", "adskeeper.com",
        "facebook.net", "connect.facebook.net", "hotjar.com", "quantserve.com"
    )

    fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        return hosts.any { h == it || h.endsWith(".$it") }
    }
}

package dz.zujaj.cast.ui

import androidx.compose.runtime.mutableStateOf

/** Lets other screens ask the browser to open a URL. */
object Nav {
    val pendingUrl = mutableStateOf<String?>(null)
}

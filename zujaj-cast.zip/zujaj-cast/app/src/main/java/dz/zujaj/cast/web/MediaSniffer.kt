package dz.zujaj.cast.web

data class Detected(val url: String, val label: String)

object MediaSniffer {
    private val ext = Regex("\\.(m3u8|mp4|mpd|webm|mkv|m4v|mov)(\$|[?#&/])", RegexOption.IGNORE_CASE)

    /** True for URLs that look like a video file or playlist (HLS segments .ts are ignored on purpose). */
    fun looksLikeMedia(url: String): Boolean = ext.containsMatchIn(url)

    fun label(url: String): String {
        val noQuery = url.substringBefore('?')
        val host = noQuery.substringAfter("://").substringBefore('/')
        val file = noQuery.substringAfterLast('/')
        return if (file.isBlank()) host else "$host / $file"
    }
}

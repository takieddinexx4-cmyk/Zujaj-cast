package dz.zujaj.cast.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import dz.zujaj.cast.R
import dz.zujaj.cast.cast.CastManager
import dz.zujaj.cast.cast.Kind
import dz.zujaj.cast.mirror.MirrorService
import dz.zujaj.cast.mirror.Quality

@Composable
fun MirrorScreen(modifier: Modifier) {
    val ctx = LocalContext.current
    val devices by CastManager.devices.collectAsState()
    val scanning by CastManager.scanning.collectAsState()
    val mirroring by CastManager.mirroring.collectAsState()
    var quality by remember { mutableStateOf(Quality.BALANCED) }
    var deviceId by remember { mutableStateOf<String?>(null) }
    var hint by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { CastManager.scan() }

    // Raw TS streaming works with DLNA TVs; Chromecast mirroring goes through the system cast feature.
    val targets = devices.filter { it.kind == Kind.DLNA }

    val projection = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val id = deviceId
        if (r.resultCode == Activity.RESULT_OK && data != null && id != null) {
            ContextCompat.startForegroundService(ctx, MirrorService.startIntent(ctx, r.resultCode, data, id, quality))
        }
    }
    val askProjection = {
        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection.launch(mpm.createScreenCaptureIntent())
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { askProjection() }

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.mirror_title), color = Color.White, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.mirror_body), color = Color.White.copy(alpha = 0.75f))
            }
        }

        Text(stringResource(R.string.quality), color = Color.White, fontWeight = FontWeight.SemiBold)
        val labels = mapOf(
            Quality.SAVER to R.string.q_saver, Quality.BALANCED to R.string.q_balanced,
            Quality.HIGH to R.string.q_high, Quality.ULTRA to R.string.q_ultra
        )
        Quality.values().forEach { q ->
            GlassChip(stringResource(labels.getValue(q)), selected = quality == q, modifier = Modifier.fillMaxWidth()) {
                quality = q
            }
        }

        Text(stringResource(R.string.target_device), color = Color.White, fontWeight = FontWeight.SemiBold)
        if (scanning) Text(stringResource(R.string.scanning), color = Color.White.copy(alpha = 0.6f))
        if (!scanning && targets.isEmpty()) Text(stringResource(R.string.no_devices), color = Color.White.copy(alpha = 0.7f))
        targets.forEach { d ->
            GlassChip(d.name, selected = deviceId == d.id, modifier = Modifier.fillMaxWidth()) { deviceId = d.id }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassChip(stringResource(R.string.rescan), selected = false) { CastManager.scan() }
        }

        if (hint) Text(stringResource(R.string.pick_device_first), color = Color.White.copy(alpha = 0.8f))
        if (mirroring) {
            GlassButton(stringResource(R.string.stop_mirror), Modifier.fillMaxWidth()) {
                ctx.startService(MirrorService.stopIntent(ctx))
            }
        } else {
            GlassButton(stringResource(R.string.start_mirror), Modifier.fillMaxWidth()) {
                if (deviceId == null) {
                    hint = true
                } else {
                    hint = false
                    if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else askProjection()
                }
            }
        }

        GlassChip(stringResource(R.string.system_cast), selected = false, modifier = Modifier.fillMaxWidth()) {
            val i = Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { ctx.startActivity(i) }.onFailure {
                runCatching { ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        }
    }
}

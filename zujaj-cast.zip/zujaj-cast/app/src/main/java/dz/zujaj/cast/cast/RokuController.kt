package dz.zujaj.cast.cast

import dz.zujaj.cast.net.Http
import java.net.URLEncoder

/**
 * Roku External Control Protocol (port 8060). EXPERIMENTAL: opens Roku Media Player (channel 2213)
 * with the URL. Behaviour differs between Roku models and software versions.
 */
object RokuController {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun play(base: String, item: MediaItem) {
        val fmt = if (item.mime.contains("mpegurl", ignoreCase = true)) "hls" else "mp4"
        val url = "$base/launch/2213?t=v&u=${enc(item.url)}&videoName=${enc(item.title)}&videoFormat=$fmt"
        Http.post(url, emptyMap(), "")
    }

    fun togglePause(base: String) = Http.post("$base/keypress/Play", emptyMap(), "")
    fun stop(base: String) = Http.post("$base/keypress/Home", emptyMap(), "")
}

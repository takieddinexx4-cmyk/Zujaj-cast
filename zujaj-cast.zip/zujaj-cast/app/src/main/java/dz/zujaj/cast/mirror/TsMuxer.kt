package dz.zujaj.cast.mirror

import java.io.ByteArrayOutputStream

/**
 * Minimal MPEG-2 transport stream muxer for one H.264 video stream (Annex-B input, no audio).
 * Every call to [frame] returns the bytes of one access unit as 188-byte TS packets; PAT/PMT are
 * repeated before every keyframe so a player can join the stream at any keyframe.
 */
class TsMuxer {
    private val pmtPid = 0x1000
    private val videoPid = 0x100
    private var ccPat = 0
    private var ccPmt = 0
    private var ccVideo = 0
    private var config: ByteArray = ByteArray(0)

    /** SPS+PPS as delivered by MediaCodec (BUFFER_FLAG_CODEC_CONFIG). */
    fun setConfig(sps: ByteArray) {
        config = sps
    }

    fun frame(annexB: ByteArray, ptsUs: Long, keyframe: Boolean): ByteArray {
        val out = ByteArrayOutputStream(annexB.size + 1024)
        if (keyframe) {
            out.write(psi(0, patSection(), ccPat++))
            out.write(psi(pmtPid, pmtSection(), ccPmt++))
        }
        val pts = ((ptsUs * 9 / 100) + 90_000L) and 0x1FFFFFFFFL
        val pcr = (pts - 9_000L).coerceAtLeast(0)

        // Access unit delimiter, then SPS/PPS before keyframes, then the frame itself.
        val es = ByteArrayOutputStream(annexB.size + config.size + 8)
        es.write(byteArrayOf(0, 0, 0, 1, 0x09, 0xF0.toByte()))
        if (keyframe) es.write(config)
        es.write(annexB)
        val esBytes = es.toByteArray()

        val pes = ByteArrayOutputStream(esBytes.size + 19)
        pes.write(byteArrayOf(0, 0, 1, 0xE0.toByte(), 0, 0, 0x80.toByte(), 0x80.toByte(), 5))
        pes.write(ptsBytes(pts))
        pes.write(esBytes)

        packetize(videoPid, pes.toByteArray(), pcr, keyframe, out)
        return out.toByteArray()
    }

    private fun ptsBytes(pts: Long) = byteArrayOf(
        (0x21 or (((pts shr 30) and 0x07).toInt() shl 1)).toByte(),
        ((pts shr 22) and 0xFF).toByte(),
        ((((pts shr 15) and 0x7F).toInt() shl 1) or 1).toByte(),
        ((pts shr 7) and 0xFF).toByte(),
        (((pts and 0x7F).toInt() shl 1) or 1).toByte()
    )

    private fun packetize(pid: Int, payload: ByteArray, pcr: Long, randomAccess: Boolean, out: ByteArrayOutputStream) {
        var off = 0
        var first = true
        while (off < payload.size) {
            val pkt = ByteArray(188) { 0xFF.toByte() }
            val remaining = payload.size - off
            val baseAf = if (first) 8 else 0 // 1 length + 1 flags + 6 PCR, only on the first packet
            val take = minOf(184 - baseAf, remaining)
            val totalAf = 184 - take // adaptation field size, stuffing included
            pkt[0] = 0x47
            pkt[1] = ((if (first) 0x40 else 0) or ((pid shr 8) and 0x1F)).toByte()
            pkt[2] = (pid and 0xFF).toByte()
            val afc = if (totalAf > 0) 3 else 1
            pkt[3] = ((afc shl 4) or (ccVideo++ and 0x0F)).toByte()
            if (totalAf > 0) {
                pkt[4] = (totalAf - 1).toByte()
                if (totalAf >= 2) {
                    var flags = 0
                    if (first) {
                        flags = flags or 0x10
                        if (randomAccess) flags = flags or 0x40
                    }
                    pkt[5] = flags.toByte()
                    if (first) {
                        pkt[6] = ((pcr shr 25) and 0xFF).toByte()
                        pkt[7] = ((pcr shr 17) and 0xFF).toByte()
                        pkt[8] = ((pcr shr 9) and 0xFF).toByte()
                        pkt[9] = ((pcr shr 1) and 0xFF).toByte()
                        pkt[10] = ((((pcr and 1L).toInt()) shl 7) or 0x7E).toByte()
                        pkt[11] = 0
                    }
                }
            }
            System.arraycopy(payload, off, pkt, 4 + totalAf, take)
            out.write(pkt)
            off += take
            first = false
        }
    }

    private fun psi(pid: Int, section: ByteArray, cc: Int): ByteArray {
        val pkt = ByteArray(188) { 0xFF.toByte() }
        pkt[0] = 0x47
        pkt[1] = (0x40 or ((pid shr 8) and 0x1F)).toByte()
        pkt[2] = (pid and 0xFF).toByte()
        pkt[3] = (0x10 or (cc and 0x0F)).toByte()
        pkt[4] = 0 // pointer field
        System.arraycopy(section, 0, pkt, 5, section.size)
        return pkt
    }

    private fun patSection(): ByteArray {
        val b = byteArrayOf(
            0x00, 0xB0.toByte(), 13, 0x00, 0x01, 0xC1.toByte(), 0, 0,
            0x00, 0x01, (0xE0 or (pmtPid shr 8)).toByte(), (pmtPid and 0xFF).toByte()
        )
        return withCrc(b)
    }

    private fun pmtSection(): ByteArray {
        val b = byteArrayOf(
            0x02, 0xB0.toByte(), 18, 0x00, 0x01, 0xC1.toByte(), 0, 0,
            (0xE0 or (videoPid shr 8)).toByte(), (videoPid and 0xFF).toByte(), 0xF0.toByte(), 0x00,
            0x1B, (0xE0 or (videoPid shr 8)).toByte(), (videoPid and 0xFF).toByte(), 0xF0.toByte(), 0x00
        )
        return withCrc(b)
    }

    private fun withCrc(b: ByteArray): ByteArray {
        var crc = -1 // 0xFFFFFFFF
        for (x in b) {
            crc = crc xor ((x.toInt() and 0xFF) shl 24)
            repeat(8) { crc = if (crc < 0) (crc shl 1) xor 0x04C11DB7 else crc shl 1 }
        }
        return b + byteArrayOf((crc ushr 24).toByte(), (crc ushr 16).toByte(), (crc ushr 8).toByte(), crc.toByte())
    }
}

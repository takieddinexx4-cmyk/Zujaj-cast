package dz.zujaj.cast

import android.app.Application
import dz.zujaj.cast.cast.CastManager
import dz.zujaj.cast.data.Store

class ZujajApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        CastManager.init(this)
    }
}

package dz.zujaj.cast.cast

import dz.zujaj.cast.net.Http

/** Plays a URL on a UPnP/DLNA MediaRenderer through its AVTransport service. Blocking: call off the main thread. */
object DlnaController {

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    private fun soap(control: String, action: String, args: String) {
        val body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>" +
            "<u:$action xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
            "<InstanceID>0</InstanceID>$args</u:$action></s:Body></s:Envelope>"
        Http.post(
            control,
            mapOf(
                "Content-Type" to "text/xml; charset=\"utf-8\"",
                "SOAPACTION" to "\"urn:schemas-upnp-org:service:AVTransport:1#$action\""
            ),
            body
        )
    }

    private fun didl(item: MediaItem): String {
        val cls = when {
            item.mime.startsWith("audio") -> "object.item.audioItem.musicTrack"
            item.mime.startsWith("image") -> "object.item.imageItem.photo"
            else -> "object.item.videoItem"
        }
        return "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
            "<item id=\"0\" parentID=\"-1\" restricted=\"1\"><dc:title>${esc(item.title)}</dc:title>" +
            "<upnp:class>$cls</upnp:class>" +
            "<res protocolInfo=\"http-get:*:${item.mime}:*\">${esc(item.url)}</res></item></DIDL-Lite>"
    }

    fun play(control: String, item: MediaItem) {
        runCatching { soap(control, "Stop", "") } // some TVs refuse a new URI while playing
        soap(
            control, "SetAVTransportURI",
            "<CurrentURI>${esc(item.url)}</CurrentURI><CurrentURIMetaData>${esc(didl(item))}</CurrentURIMetaData>"
        )
        soap(control, "Play", "<Speed>1</Speed>")
    }

    fun pause(control: String) = soap(control, "Pause", "")
    fun resume(control: String) = soap(control, "Play", "<Speed>1</Speed>")
    fun stop(control: String) = soap(control, "Stop", "")
}

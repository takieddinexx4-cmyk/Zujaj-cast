package dz.zujaj.cast.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import dz.zujaj.cast.R
import dz.zujaj.cast.cast.CastManager
import dz.zujaj.cast.cast.Kind
import dz.zujaj.cast.cast.MediaItem
import dz.zujaj.cast.cast.mimeFor
import dz.zujaj.cast.web.Detected

/** Step 1: pick which detected video (skipped when there is only one). Step 2: pick the TV. */
@Composable
fun CastDialog(videos: List<Detected>, title: String, onDismiss: () -> Unit) {
    var chosen by remember { mutableStateOf(if (videos.size == 1) videos.first() else null) }
    val devices by CastManager.devices.collectAsState()
    val scanning by CastManager.scanning.collectAsState()
    LaunchedEffect(Unit) { CastManager.scan() }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        GlassCard(
            Modifier.padding(20.dp).fillMaxWidth().background(Color(0xE60B0C12), RoundedCornerShape(26.dp)),
            radius = 26.dp
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val pick = chosen
                if (pick == null) {
                    Text(stringResource(R.string.pick_video), color = Color.White, fontWeight = FontWeight.Bold)
                    LazyColumn(Modifier.heightIn(max = 320.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(videos) { v ->
                            GlassCard(Modifier.fillMaxWidth(), radius = 16.dp, onClick = { chosen = v }) {
                                Text(v.label, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(14.dp))
                            }
                        }
                    }
                } else {
                    Text(stringResource(R.string.pick_device), color = Color.White, fontWeight = FontWeight.Bold)
                    if (scanning) Text(stringResource(R.string.scanning), color = Color.White.copy(alpha = 0.6f))
                    if (!scanning && devices.isEmpty()) {
                        Text(stringResource(R.string.no_devices), color = Color.White.copy(alpha = 0.7f))
                    }
                    LazyColumn(Modifier.heightIn(max = 320.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(devices) { d ->
                            GlassCard(Modifier.fillMaxWidth(), radius = 16.dp, onClick = {
                                CastManager.play(d, MediaItem(pick.url, title.ifBlank { pick.label }, mimeFor(pick.url)))
                                onDismiss()
                            }) {
                                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(d.name, color = Color.White, modifier = Modifier.weight(1f))
                                    val kindName = when (d.kind) {
                                        Kind.CHROMECAST -> "Chromecast"
                                        Kind.DLNA -> "DLNA"
                                        Kind.ROKU -> "Roku"
                                    }
                                    Text(kindName, color = Color.White.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (chosen != null) GlassButton(stringResource(R.string.rescan), enabled = !scanning) { CastManager.scan() }
                    GlassButton(stringResource(R.string.close)) { onDismiss() }
                }
            }
        }
    }
}

package dz.zujaj.cast.cast

enum class Kind { CHROMECAST, DLNA, ROKU }

/** extra: Chromecast = media-router route id, DLNA = AVTransport control URL, Roku = base URL (http://ip:8060). */
data class CastDevice(val id: String, val name: String, val kind: Kind, val extra: String = "")

data class MediaItem(val url: String, val title: String, val mime: String, val live: Boolean = false)

data class NowPlaying(val device: CastDevice, val item: MediaItem, val paused: Boolean = false)

/** A message for the UI: a string resource plus optional detail text. */
data class Msg(val res: Int, val detail: String = "")

fun mimeFor(url: String): String {
    val p = url.substringBefore('?').lowercase()
    return when {
        p.endsWith(".m3u8") -> "application/x-mpegURL"
        p.endsWith(".mpd") -> "application/dash+xml"
        p.endsWith(".webm") -> "video/webm"
        p.endsWith(".mkv") -> "video/x-matroska"
        p.endsWith(".mov") -> "video/quicktime"
        p.endsWith(".mp3") -> "audio/mpeg"
        p.endsWith(".jpg") || p.endsWith(".jpeg") -> "image/jpeg"
        p.endsWith(".png") -> "image/png"
        else -> "video/mp4"
    }
}

package dz.zujaj.cast.net

import android.content.Context
import android.net.Uri
import dz.zujaj.cast.mirror.LiveHub
import java.io.BufferedOutputStream
import java.io.FileInputStream
import java.io.IOException
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Tiny HTTP server so the TV can pull things from the phone:
 *   /f/<id>   a local file chosen by the user (with Range support, so seeking works)
 *   /live.ts  the live screen-mirror stream (MPEG-TS)
 */
object MediaServer {
    private var server: ServerSocket? = null
    private lateinit var appCtx: Context
    private val files = ConcurrentHashMap<String, Pair<Uri, String>>()
    private val pool = Executors.newCachedThreadPool()

    @Volatile
    var live: LiveHub? = null

    @Synchronized
    fun ensureStarted(ctx: Context): Int {
        appCtx = ctx.applicationContext
        server?.let { return it.localPort }
        val s = ServerSocket(0, 50)
        server = s
        pool.execute {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (_: IOException) {
                    break
                }
            }
        }
        return s.localPort
    }

    fun urlForFile(ctx: Context, uri: Uri, mime: String): String {
        val id = UUID.randomUUID().toString().take(8)
        files[id] = uri to mime
        return "http://${localIp()}:${ensureStarted(ctx)}/f/$id"
    }

    fun liveUrl(ctx: Context): String = "http://${localIp()}:${ensureStarted(ctx)}/live.ts"

    fun localIp(): String {
        val cands = NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni ->
                ni.inetAddresses.toList()
                    .filter { it is Inet4Address && it.isSiteLocalAddress }
                    .map { ni.name to it.hostAddress!! }
            }
        return (cands.firstOrNull { it.first.startsWith("wlan") } ?: cands.firstOrNull())?.second ?: "127.0.0.1"
    }

    // ------------------------------------------------------------------ request handling

    private fun handle(sock: Socket) {
        try {
            sock.tcpNoDelay = true
            val input = sock.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            val reqLine = input.readLine() ?: return
            val parts = reqLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val path = parts[1].substringBefore('?')
            var range: String? = null
            while (true) {
                val l = input.readLine() ?: break
                if (l.isEmpty()) break
                if (l.startsWith("Range:", ignoreCase = true)) range = l.substringAfter(':').trim()
            }
            val out = BufferedOutputStream(sock.getOutputStream())
            when {
                method == "OPTIONS" -> respond(out, "200 OK", emptyMap())
                path == "/live.ts" -> serveLive(sock, out, method)
                path.startsWith("/f/") -> serveFile(path.removePrefix("/f/"), method, range, out)
                else -> respond(out, "404 Not Found", emptyMap())
            }
        } catch (_: Exception) {
            // client went away; nothing to do
        } finally {
            runCatching { sock.close() }
        }
    }

    private fun respond(out: BufferedOutputStream, status: String, headers: Map<String, String>) {
        val sb = StringBuilder("HTTP/1.1 $status\r\n")
        sb.append("Access-Control-Allow-Origin: *\r\n")
        sb.append("Access-Control-Allow-Headers: Range, Content-Type\r\n")
        sb.append("Connection: close\r\n")
        if (!headers.containsKey("Content-Length")) sb.append("Content-Length: 0\r\n")
        headers.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        sb.append("\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    private fun serveLive(sock: Socket, out: BufferedOutputStream, method: String) {
        val hub = live
        if (hub == null) {
            respond(out, "404 Not Found", emptyMap())
            return
        }
        val head = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: video/mp2t\r\n" +
            "Cache-Control: no-cache\r\n" +
            "Access-Control-Allow-Origin: *\r\n" +
            "transferMode.dlna.org: Streaming\r\n" +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        out.flush()
        if (method == "HEAD") return
        val client = hub.addClient()
        try {
            while (!sock.isClosed && !client.closed) {
                val b = client.q.poll(1, TimeUnit.SECONDS) ?: continue
                out.write(b)
                out.flush()
            }
        } finally {
            hub.remove(client)
        }
    }

    private fun serveFile(id: String, method: String, range: String?, out: BufferedOutputStream) {
        val entry = files[id]
        val pfd = entry?.let { runCatching { appCtx.contentResolver.openFileDescriptor(it.first, "r") }.getOrNull() }
        if (entry == null || pfd == null) {
            respond(out, "404 Not Found", emptyMap())
            return
        }
        pfd.use {
            val size = it.statSize
            var start = 0L
            var end = size - 1
            var partial = false
            if (range != null && range.startsWith("bytes=")) {
                val r = range.removePrefix("bytes=").split("-")
                if (r[0].isEmpty()) {
                    val n = r.getOrNull(1)?.toLongOrNull() ?: 0L
                    start = (size - n).coerceAtLeast(0)
                } else {
                    start = r[0].toLongOrNull() ?: 0L
                    end = r.getOrNull(1)?.toLongOrNull() ?: (size - 1)
                }
                partial = true
            }
            end = minOf(end, size - 1)
            if (start > end) {
                respond(out, "416 Range Not Satisfiable", mapOf("Content-Range" to "bytes */$size"))
                return
            }
            val len = end - start + 1
            val headers = linkedMapOf(
                "Content-Type" to entry.second,
                "Accept-Ranges" to "bytes",
                "Content-Length" to len.toString(),
                "transferMode.dlna.org" to "Streaming",
                "contentFeatures.dlna.org" to "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000"
            )
            if (partial) headers["Content-Range"] = "bytes $start-$end/$size"
            respond(out, if (partial) "206 Partial Content" else "200 OK", headers)
            if (method == "HEAD") return
            FileInputStream(it.fileDescriptor).channel.use { ch ->
                ch.position(start)
                val buf = ByteBuffer.allocate(64 * 1024)
                var left = len
                while (left > 0) {
                    buf.clear()
                    if (left < buf.capacity()) buf.limit(left.toInt())
                    val n = ch.read(buf)
                    if (n < 0) break
                    out.write(buf.array(), 0, n)
                    left -= n
                }
            }
            out.flush()
        }
    }
}

package dz.zujaj.cast.mirror

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.IntentCompat
import dz.zujaj.cast.R
import dz.zujaj.cast.cast.CastManager
import dz.zujaj.cast.cast.MediaItem
import dz.zujaj.cast.net.MediaServer

/** Foreground service that owns the screen capture (required by Android for MediaProjection). */
class MirrorService : Service() {
    private var projection: MediaProjection? = null
    private var streamer: MirrorStreamer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopAll()
            return START_NOT_STICKY
        }
        startInForeground()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        val device = CastManager.deviceById(intent.getStringExtra(EXTRA_DEVICE) ?: "")
        val quality = Quality.values().getOrElse(intent.getIntExtra(EXTRA_QUALITY, 1)) { Quality.BALANCED }
        if (data == null || device == null) {
            stopAll()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        // Android 14+ requires a callback to be registered before creating the virtual display.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() = stopAll()
        }, Handler(Looper.getMainLooper()))
        projection = p

        val hub = LiveHub()
        MediaServer.live = hub
        val s = MirrorStreamer(this, p, quality, hub)
        try {
            s.start()
        } catch (e: Exception) {
            stopAll()
            return START_NOT_STICKY
        }
        streamer = s

        CastManager.mirroring.value = true
        CastManager.play(device, MediaItem(MediaServer.liveUrl(this), "Screen", "video/mp2t", live = true))
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.mirror_notif), NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, stopIntent(this), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.mirror_notif))
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, getString(R.string.stop), stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun stopAll() {
        streamer?.stop()
        streamer = null
        projection = null
        MediaServer.live = null
        if (CastManager.mirroring.value) CastManager.stop()
        CastManager.mirroring.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (streamer != null) stopAll()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "mirror"
        private const val NOTIF_ID = 42
        const val ACTION_STOP = "dz.zujaj.cast.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_DEVICE = "device"
        const val EXTRA_QUALITY = "quality"

        fun stopIntent(ctx: Context) = Intent(ctx, MirrorService::class.java).setAction(ACTION_STOP)

        fun startIntent(ctx: Context, code: Int, data: Intent, deviceId: String, quality: Quality) =
            Intent(ctx, MirrorService::class.java)
                .putExtra(EXTRA_CODE, code)
                .putExtra(EXTRA_DATA, data)
                .putExtra(EXTRA_DEVICE, deviceId)
                .putExtra(EXTRA_QUALITY, quality.ordinal)
    }
}

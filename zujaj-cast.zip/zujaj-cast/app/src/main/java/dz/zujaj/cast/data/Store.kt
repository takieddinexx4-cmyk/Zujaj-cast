package dz.zujaj.cast.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** Tiny local store: bookmarks, history and settings. Everything stays on the phone. */
object Store {
    data class Entry(val title: String, val url: String, val ts: Long)

    private var prefs: SharedPreferences? = null

    /** Bumped on every write so Compose screens can re-read lists. */
    val version = mutableIntStateOf(0)

    var accentKey by mutableStateOf("red")
        private set
    var adblock: Boolean = true
        private set
    var home: String = "https://duckduckgo.com"
        private set

    fun init(c: Context) {
        val p = c.getSharedPreferences("zujaj", Context.MODE_PRIVATE)
        prefs = p
        accentKey = p.getString("accent", "red") ?: "red"
        adblock = p.getBoolean("adblock", true)
        home = p.getString("home", home) ?: home
    }

    fun setAccent(key: String) {
        accentKey = key
        prefs?.edit()?.putString("accent", key)?.apply()
    }

    fun setAdblock(on: Boolean) {
        adblock = on
        prefs?.edit()?.putBoolean("adblock", on)?.apply()
    }

    fun setHome(url: String) {
        home = url
        prefs?.edit()?.putString("home", url)?.apply()
    }

    private fun read(key: String): List<Entry> {
        val raw = prefs?.getString(key, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Entry(o.optString("t"), o.getString("u"), o.optLong("ts"))
            }
        }.getOrDefault(emptyList())
    }

    private fun write(key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url).put("ts", it.ts)) }
        prefs?.edit()?.putString(key, arr.toString())?.apply()
        version.intValue++
    }

    fun bookmarks(): List<Entry> = read("bm")
    fun history(): List<Entry> = read("hist")

    fun isBookmarked(url: String) = bookmarks().any { it.url == url }

    fun toggleBookmark(title: String, url: String) {
        val list = bookmarks().toMutableList()
        if (!list.removeAll { it.url == url }) {
            list.add(0, Entry(title.ifBlank { url }, url, System.currentTimeMillis()))
        }
        write("bm", list)
    }

    fun removeBookmark(url: String) = write("bm", bookmarks().filterNot { it.url == url })

    fun addHistory(title: String, url: String) {
        if (!url.startsWith("http")) return
        val list = history().filterNot { it.url == url }.toMutableList()
        list.add(0, Entry(title.ifBlank { url }, url, System.currentTimeMillis()))
        write("hist", list.take(200))
    }

    fun clearHistory() = write("hist", emptyList())
}

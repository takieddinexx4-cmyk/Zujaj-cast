package dz.zujaj.cast.net

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Minimal blocking HTTP helper for talking to TVs on the local network. Call off the main thread. */
object Http {
    fun get(url: String, timeoutMs: Int = 3000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs
        try {
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    fun post(url: String, headers: Map<String, String>, body: String, timeoutMs: Int = 6000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs
        c.doOutput = true
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        try {
            val bytes = body.toByteArray(Charsets.UTF_8)
            c.setFixedLengthStreamingMode(bytes.size)
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            val text = (if (code >= 400) c.errorStream else c.inputStream)?.bufferedReader()?.readText().orEmpty()
            if (code >= 300) throw IOException("HTTP $code ${text.take(120)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}

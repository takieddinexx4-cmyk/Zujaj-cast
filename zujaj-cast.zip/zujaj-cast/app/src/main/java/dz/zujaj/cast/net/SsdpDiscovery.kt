package dz.zujaj.cast.net

import android.content.Context
import android.net.wifi.WifiManager
import dz.zujaj.cast.cast.CastDevice
import dz.zujaj.cast.cast.Kind
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.StringReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.net.URL
import javax.xml.parsers.DocumentBuilderFactory

/** Finds UPnP/DLNA media renderers (most smart TVs) and Roku boxes on the local Wi-Fi via SSDP. */
object SsdpDiscovery {

    fun search(ctx: Context, timeoutMs: Int = 4000): List<CastDevice> {
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("zujaj-ssdp").apply {
            setReferenceCounted(false)
            acquire()
        }
        val locations = LinkedHashMap<String, String>() // location url -> search target
        try {
            val sock = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(0))
                soTimeout = 600
            }
            val group = InetAddress.getByName("239.255.255.250")
            for (st in listOf("urn:schemas-upnp-org:device:MediaRenderer:1", "roku:ecp")) {
                val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                    "HOST: 239.255.255.250:1900\r\n" +
                    "MAN: \"ssdp:discover\"\r\n" +
                    "MX: 2\r\n" +
                    "ST: $st\r\n\r\n").toByteArray()
                repeat(2) { sock.send(DatagramPacket(msg, msg.size, group, 1900)) }
            }
            val end = System.currentTimeMillis() + timeoutMs
            val buf = ByteArray(4096)
            while (System.currentTimeMillis() < end) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    val text = String(p.data, 0, p.length)
                    var loc: String? = null
                    var st = ""
                    text.lines().forEach { line ->
                        val i = line.indexOf(':')
                        if (i > 0) {
                            when (line.substring(0, i).trim().uppercase()) {
                                "LOCATION" -> loc = line.substring(i + 1).trim()
                                "ST" -> st = line.substring(i + 1).trim()
                            }
                        }
                    }
                    loc?.let { locations.putIfAbsent(it, st) }
                } catch (_: SocketTimeoutException) {
                }
            }
            sock.close()
        } finally {
            lock.release()
        }
        return locations.mapNotNull { (loc, st) ->
            runCatching { if (st.startsWith("roku")) describeRoku(loc) else describeDlna(loc) }.getOrNull()
        }.distinctBy { it.id }
    }

    private fun describeRoku(location: String): CastDevice {
        val base = location.trimEnd('/')
        val xml = Http.get("$base/query/device-info")
        val name = Regex("<friendly-device-name>(.*?)</friendly-device-name>").find(xml)?.groupValues?.get(1)
            ?: Regex("<model-name>(.*?)</model-name>").find(xml)?.groupValues?.get(1)
            ?: "Roku"
        return CastDevice("roku:$base", name, Kind.ROKU, base)
    }

    private fun describeDlna(location: String): CastDevice? {
        val xml = Http.get(location)
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(xml)))
        val name = doc.getElementsByTagName("friendlyName").item(0)?.textContent?.trim() ?: "TV"
        val urlBase = doc.getElementsByTagName("URLBase").item(0)?.textContent?.trim()
        val services = doc.getElementsByTagName("service")
        var control: String? = null
        for (i in 0 until services.length) {
            val s = services.item(i) as Element
            val type = s.getElementsByTagName("serviceType").item(0)?.textContent.orEmpty()
            if (type.contains("AVTransport")) {
                control = s.getElementsByTagName("controlURL").item(0)?.textContent?.trim()
            }
        }
        val c = control ?: return null
        val abs = URL(URL(urlBase ?: location), c).toString()
        return CastDevice("dlna:$abs", name, Kind.DLNA, abs)
    }
}

package dz.zujaj.cast.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

/** Two accent palettes on a near-black base: muted red (default) or blue. */
enum class Accent(val main: Color, val soft: Color, val glow: Color) {
    RED(Color(0xFFC0394B), Color(0xFF7A1F2E), Color(0xFF5A0F1E)),
    BLUE(Color(0xFF3C6FE0), Color(0xFF24428F), Color(0xFF14285C));

    companion object {
        fun of(key: String) = if (key == "blue") BLUE else RED
    }
}

val LocalAccent = compositionLocalOf { Accent.RED }
val Ink = Color(0xFF05060A)

@Composable
fun ZujajTheme(accent: Accent, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent.main,
            background = Ink,
            surface = Color(0xFF0B0C12),
            onSurface = Color.White,
            onBackground = Color.White
        )
    ) {
        CompositionLocalProvider(LocalAccent provides accent, content = content)
    }
}

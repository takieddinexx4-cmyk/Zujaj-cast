package dz.zujaj.cast.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dz.zujaj.cast.R
import dz.zujaj.cast.data.Store
import dz.zujaj.cast.net.MediaServer
import dz.zujaj.cast.web.Detected

@Composable
fun LibraryScreen(modifier: Modifier, onOpen: (String) -> Unit, onCastLocal: (Detected, String) -> Unit) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val mime = ctx.contentResolver.getType(uri) ?: "video/mp4"
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "video"
            onCastLocal(Detected(MediaServer.urlForFile(ctx, uri, mime), name), name)
        }
    }
    val bookmarks = Store.version.intValue.let { Store.bookmarks() }
    val history = Store.version.intValue.let { Store.history() }

    LazyColumn(modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(stringResource(R.string.my_files), color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp))
        }
        item {
            GlassButton(stringResource(R.string.pick_file), Modifier.fillMaxWidth()) {
                picker.launch(arrayOf("video/*", "audio/*", "image/*"))
            }
        }
        item {
            Text(stringResource(R.string.bookmarks), color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp))
        }
        if (bookmarks.isEmpty()) item { Text(stringResource(R.string.empty), color = Color.White.copy(alpha = 0.6f)) }
        items(bookmarks) { e -> EntryRow(e.title, e.url) { onOpen(e.url) } }

        item {
            Text(stringResource(R.string.history), color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp))
        }
        if (history.isEmpty()) {
            item { Text(stringResource(R.string.empty), color = Color.White.copy(alpha = 0.6f)) }
        } else {
            item { GlassButton(stringResource(R.string.clear), Modifier.fillMaxWidth()) { Store.clearHistory() } }
        }
        items(history) { e -> EntryRow(e.title, e.url) { onOpen(e.url) } }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun EntryRow(title: String, url: String, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), radius = 16.dp, onClick = onClick) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(url, color = Color.White.copy(alpha = 0.5f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

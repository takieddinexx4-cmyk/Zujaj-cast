package dz.zujaj.cast.mirror

import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue

/**
 * Fan-out for the live MPEG-TS stream. Each HTTP client gets its own bounded queue so one slow TV
 * can never block the encoder: if its queue fills up it simply waits for the next keyframe.
 */
class LiveHub {
    class Client {
        val q = LinkedBlockingQueue<ByteArray>(240)

        @Volatile var started = false

        @Volatile var closed = false
    }

    private val clients = CopyOnWriteArrayList<Client>()

    fun addClient(): Client = Client().also { clients.add(it) }

    fun remove(c: Client) {
        c.closed = true
        clients.remove(c)
    }

    fun broadcast(bytes: ByteArray, keyframe: Boolean) {
        for (c in clients) {
            if (!c.started) {
                if (!keyframe) continue
                c.q.clear()
                c.started = true
            }
            if (!c.q.offer(bytes)) c.started = false
        }
    }

    fun close() {
        clients.forEach { it.closed = true }
        clients.clear()
    }
}

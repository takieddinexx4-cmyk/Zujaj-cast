package dz.zujaj.cast

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dz.zujaj.cast.cast.CastManager
import dz.zujaj.cast.cast.NowPlaying
import dz.zujaj.cast.data.Store
import dz.zujaj.cast.mirror.MirrorService
import dz.zujaj.cast.ui.Accent
import dz.zujaj.cast.ui.BrowserScreen
import dz.zujaj.cast.ui.CastDialog
import dz.zujaj.cast.ui.GlassBackground
import dz.zujaj.cast.ui.GlassButton
import dz.zujaj.cast.ui.GlassCard
import dz.zujaj.cast.ui.LibraryScreen
import dz.zujaj.cast.ui.LocalAccent
import dz.zujaj.cast.ui.MirrorScreen
import dz.zujaj.cast.ui.Nav
import dz.zujaj.cast.ui.SettingsScreen
import dz.zujaj.cast.ui.ZujajTheme
import dz.zujaj.cast.web.Detected

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ZujajRoot() }
    }
}

enum class Tab(val label: Int, val icon: ImageVector) {
    BROWSE(R.string.tab_browse, Icons.Default.Search),
    MIRROR(R.string.tab_mirror, Icons.Default.PlayArrow),
    LIBRARY(R.string.tab_library, Icons.Default.Star),
    SETTINGS(R.string.tab_settings, Icons.Default.Settings)
}

private class CastRequest(val videos: List<Detected>, val title: String)

@Composable
fun ZujajRoot() {
    ZujajTheme(Accent.of(Store.accentKey)) {
        var tab by remember { mutableStateOf(Tab.BROWSE) }
        var castReq by remember { mutableStateOf<CastRequest?>(null) }
        val now by CastManager.now.collectAsState()
        val msg by CastManager.message.collectAsState()

        GlassBackground {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    // The browser stays composed on every tab so the page is not reloaded when you come back.
                    BrowserScreen(
                        modifier = if (tab == Tab.BROWSE) Modifier.fillMaxSize() else Modifier.size(0.dp),
                        onRequestCast = { v, t -> castReq = CastRequest(v, t) }
                    )
                    when (tab) {
                        Tab.MIRROR -> MirrorScreen(Modifier.fillMaxSize())
                        Tab.LIBRARY -> LibraryScreen(
                            Modifier.fillMaxSize(),
                            onOpen = { url -> Nav.pendingUrl.value = url; tab = Tab.BROWSE },
                            onCastLocal = { v, t -> castReq = CastRequest(listOf(v), t) }
                        )
                        Tab.SETTINGS -> SettingsScreen(Modifier.fillMaxSize())
                        Tab.BROWSE -> {}
                    }
                }
                now?.let { NowPlayingBar(it) }
                msg?.let { m ->
                    GlassCard(
                        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(),
                        radius = 18.dp,
                        onClick = { CastManager.message.value = null }
                    ) {
                        Text(
                            stringResource(m.res, m.detail), color = Color.White,
                            modifier = Modifier.padding(14.dp), maxLines = 3, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                BottomNav(tab) { tab = it }
            }
        }

        castReq?.let { r -> CastDialog(r.videos, r.title) { castReq = null } }
    }
}

@Composable
private fun NowPlayingBar(n: NowPlaying) {
    val ctx = LocalContext.current
    val mirroring by CastManager.mirroring.collectAsState()
    GlassCard(Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(), radius = 22.dp) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.now_casting, n.device.name), color = Color.White, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(n.item.title, color = Color.White.copy(alpha = 0.6f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
            }
            if (!mirroring) {
                GlassButton(stringResource(if (n.paused) R.string.resume else R.string.pause)) { CastManager.togglePause() }
            }
            GlassButton(stringResource(R.string.stop)) {
                if (mirroring) ctx.startService(MirrorService.stopIntent(ctx)) else CastManager.stop()
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Tab, onSelect: (Tab) -> Unit) {
    val accent = LocalAccent.current
    GlassCard(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp).navigationBarsPadding().fillMaxWidth(),
        radius = 32.dp
    ) {
        Row(Modifier.padding(6.dp)) {
            Tab.values().forEach { t ->
                val sel = t == selected
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                        .background(if (sel) accent.main.copy(alpha = 0.35f) else Color.Transparent)
                        .clickable { onSelect(t) }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(t.icon, null, tint = Color.White)
                    Text(stringResource(t.label), color = Color.White, fontSize = 11.sp)
                }
            }
        }
    }
}

package dz.zujaj.cast.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import dz.zujaj.cast.R
import dz.zujaj.cast.data.Store
import dz.zujaj.cast.web.AdBlocker
import dz.zujaj.cast.web.Detected
import dz.zujaj.cast.web.MediaSniffer
import org.json.JSONArray
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.net.URLEncoder

private fun normalise(raw: String): String {
    val s = raw.trim()
    return when {
        s.startsWith("http://") || s.startsWith("https://") -> s
        s.contains(' ') || !s.contains('.') -> "https://duckduckgo.com/?q=" + URLEncoder.encode(s, "UTF-8")
        else -> "https://$s"
    }
}

private const val SCAN_JS =
    "(function(){var r=[];document.querySelectorAll('video,source').forEach(function(e){" +
        "var s=e.currentSrc||e.src;if(s&&s.indexOf('blob:')!==0&&s.indexOf('http')===0)r.push(s)});" +
        "return JSON.stringify(r)})()"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(modifier: Modifier, onRequestCast: (List<Detected>, String) -> Unit) {
    val accent = LocalAccent.current
    var input by remember { mutableStateOf(Store.home) }
    var progress by remember { mutableIntStateOf(100) }
    var title by remember { mutableStateOf("") }
    var currentUrl by remember { mutableStateOf("") }
    var canBack by remember { mutableStateOf(false) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var showNone by remember { mutableStateOf(false) }
    val detected = remember { mutableStateListOf<Detected>() }
    val ctx = LocalContext.current

    BackHandler(enabled = canBack) { webView?.goBack() }

    val pending = Nav.pendingUrl.value
    LaunchedEffect(pending, webView) {
        val w = webView
        if (pending != null && w != null) {
            w.loadUrl(pending)
            Nav.pendingUrl.value = null
        }
    }

    fun addDetected(u: String) {
        if (detected.none { it.url == u }) detected.add(Detected(u, MediaSniffer.label(u)))
    }

    Column(modifier) {
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), radius = 22.dp) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White),
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { webView?.loadUrl(normalise(input)) }),
                    modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text(stringResource(R.string.url_hint), color = Color.White.copy(alpha = 0.45f))
                        inner()
                    }
                )
                val bm = Store.version.intValue.let { Store.isBookmarked(currentUrl) }
                Icon(
                    Icons.Default.Star, null,
                    tint = if (bm) accent.main else Color.White.copy(alpha = 0.4f),
                    modifier = Modifier.padding(horizontal = 6.dp).size(26.dp).clip(RoundedCornerShape(8.dp))
                        .clickable { if (currentUrl.isNotEmpty()) Store.toggleBookmark(title, currentUrl) }
                )
                Icon(
                    Icons.Default.Refresh, null, tint = Color.White,
                    modifier = Modifier.padding(horizontal = 6.dp).size(26.dp).clip(RoundedCornerShape(8.dp))
                        .clickable { webView?.reload() }
                )
            }
        }
        if (progress < 100) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                color = accent.main, trackColor = Color.Transparent
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(22.dp))) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.setSupportMultipleWindows(false)
                        settings.javaScriptCanOpenWindowsAutomatically = false
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                                if (Store.adblock && AdBlocker.isBlocked(request.url.host)) {
                                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                                }
                                val u = request.url.toString()
                                if (MediaSniffer.looksLikeMedia(u)) view.post { addDetected(u) }
                                return null
                            }

                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                val s = request.url.scheme
                                return s != "http" && s != "https" // block intent:// and app-store pop-ups
                            }

                            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                                detected.clear()
                                currentUrl = url
                                input = url
                            }

                            override fun onPageFinished(view: WebView, url: String) {
                                canBack = view.canGoBack()
                                title = view.title.orEmpty()
                                Store.addHistory(title, url)
                            }

                            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                                canBack = view.canGoBack()
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView, newProgress: Int) {
                                progress = newProgress
                            }

                            override fun onReceivedTitle(view: WebView, t: String) {
                                title = t
                            }
                        }
                        webView = this
                        loadUrl(normalise(Store.home))
                    }
                },
                onRelease = { it.destroy() }
            )
            GlassButton(
                text = stringResource(R.string.cast) + if (detected.isNotEmpty()) " · ${detected.size}" else "",
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) {
                webView?.evaluateJavascript(SCAN_JS) { res ->
                    runCatching {
                        val s = JSONTokener(res).nextValue() as? String
                        if (s != null) {
                            val arr = JSONArray(s)
                            for (i in 0 until arr.length()) addDetected(arr.getString(i))
                        }
                    }
                    if (detected.isEmpty()) showNone = true else onRequestCast(detected.toList(), title)
                }
            }
        }
    }

    if (showNone) {
        AlertDialog(
            onDismissRequest = { showNone = false },
            confirmButton = { TextButton({ showNone = false }) { Text(stringResource(R.string.ok)) } },
            title = { Text(stringResource(R.string.no_video_title)) },
            text = { Text(stringResource(R.string.no_video_body)) }
        )
    }
}

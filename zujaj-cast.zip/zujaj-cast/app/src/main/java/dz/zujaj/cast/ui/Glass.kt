package dz.zujaj.cast.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Black canvas with two soft coloured glows. The "glass" panels float above it. */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val a = LocalAccent.current
    Box(Modifier.fillMaxSize().background(Ink)) {
        Box(
            Modifier.size(460.dp).offset((-140).dp, (-120).dp)
                .background(Brush.radialGradient(listOf(a.glow.copy(alpha = 0.95f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.size(420.dp).align(Alignment.BottomEnd).offset(120.dp, 100.dp)
                .background(Brush.radialGradient(listOf(a.main.copy(alpha = 0.30f), Color.Transparent)), CircleShape)
        )
        content()
    }
}

/** Translucent panel with a soft white edge, in the spirit of iOS "liquid glass". */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    var m = modifier
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.05f))))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.2f))),
            shape
        )
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m, content = content)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val a = LocalAccent.current
    val alpha = if (enabled) 0.92f else 0.3f
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(a.main.copy(alpha = alpha), a.soft.copy(alpha = alpha))))
            .border(1.dp, Color.White.copy(alpha = 0.3f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) a.main.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.08f))
            .border(1.dp, Color.White.copy(alpha = if (selected) 0.5f else 0.2f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White)
    }
}

fun Modifier.screenPadding() = this.padding(horizontal = 16.dp, vertical = 8.dp)

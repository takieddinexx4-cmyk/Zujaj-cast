package dz.zujaj.cast.cast

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import dz.zujaj.cast.R
import dz.zujaj.cast.net.SsdpDiscovery
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/** One entry point for every kind of receiver: Chromecast (Cast SDK), DLNA/UPnP, Roku. */
object CastManager {
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())

    private val dlna = MutableStateFlow<List<CastDevice>>(emptyList())
    private val chrome = MutableStateFlow<List<CastDevice>>(emptyList())
    val devices: StateFlow<List<CastDevice>> =
        combine(chrome, dlna) { a, b -> a + b }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    val scanning = MutableStateFlow(false)
    val now = MutableStateFlow<NowPlaying?>(null)
    val message = MutableStateFlow<Msg?>(null)
    val mirroring = MutableStateFlow(false)

    private val routes = ConcurrentHashMap<String, MediaRouter.RouteInfo>()
    private var router: MediaRouter? = null
    private var selector: MediaRouteSelector? = null
    private var castCtx: CastContext? = null
    private var pending: MediaItem? = null
    private var pendingDevice: CastDevice? = null
    private var selectedRouteId: String? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        main.post { setupChromecast() }
    }

    fun deviceById(id: String): CastDevice? = devices.value.firstOrNull { it.id == id }

    // ---------------------------------------------------------------- discovery

    private val routeCb = object : MediaRouter.Callback() {
        override fun onRouteAdded(router: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes()
        override fun onRouteRemoved(router: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes()
        override fun onRouteChanged(router: MediaRouter, route: MediaRouter.RouteInfo) = refreshRoutes()
    }

    private fun setupChromecast() {
        runCatching {
            val r = MediaRouter.getInstance(app)
            val sel = MediaRouteSelector.Builder()
                .addControlCategory(
                    CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID)
                ).build()
            router = r
            selector = sel
            r.addCallback(sel, routeCb, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
            sessionCtx()
        }
    }

    private fun refreshRoutes() {
        val r = router ?: return
        val sel = selector ?: return
        val list = r.routes.filter { !it.isDefault && it.matchesSelector(sel) }
        routes.clear()
        list.forEach { routes[it.id] = it }
        chrome.value = list.map { CastDevice("cc:${it.id}", it.name, Kind.CHROMECAST, it.id) }
    }

    fun scan() {
        if (scanning.value) return
        scanning.value = true
        main.post {
            runCatching {
                router?.addCallback(
                    selector!!, routeCb,
                    MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY or MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN
                )
            }
            refreshRoutes()
        }
        scope.launch {
            dlna.value = runCatching { SsdpDiscovery.search(app) }.getOrDefault(emptyList())
            main.post {
                runCatching {
                    router?.addCallback(selector!!, routeCb, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
                }
                refreshRoutes()
            }
            scanning.value = false
        }
    }

    // ---------------------------------------------------------------- playback

    fun play(d: CastDevice, item: MediaItem) {
        message.value = null
        when (d.kind) {
            Kind.CHROMECAST -> playChromecast(d, item)
            Kind.DLNA -> launchOn(d, item) { DlnaController.play(d.extra, item) }
            Kind.ROKU -> launchOn(d, item) { RokuController.play(d.extra, item) }
        }
    }

    private fun launchOn(d: CastDevice, item: MediaItem, block: () -> Unit) {
        scope.launch {
            try {
                block()
                now.value = NowPlaying(d, item)
            } catch (e: Exception) {
                message.value = Msg(R.string.cast_failed, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun togglePause() {
        val n = now.value ?: return
        val d = n.device
        when (d.kind) {
            Kind.CHROMECAST -> main.post {
                val c = castCtx?.sessionManager?.currentCastSession?.remoteMediaClient ?: return@post
                if (n.paused) c.play() else c.pause()
            }
            Kind.DLNA -> scope.launch {
                runCatching { if (n.paused) DlnaController.resume(d.extra) else DlnaController.pause(d.extra) }
            }
            Kind.ROKU -> scope.launch { runCatching { RokuController.togglePause(d.extra) } }
        }
        now.value = n.copy(paused = !n.paused)
    }

    fun stop() {
        val n = now.value
        now.value = null
        if (n == null) return
        val d = n.device
        when (d.kind) {
            Kind.CHROMECAST -> main.post { castCtx?.sessionManager?.endCurrentSession(true) }
            Kind.DLNA -> scope.launch { runCatching { DlnaController.stop(d.extra) } }
            Kind.ROKU -> scope.launch { runCatching { RokuController.stop(d.extra) } }
        }
    }

    // ---------------------------------------------------------------- Chromecast session

    private fun sessionCtx(): CastContext? {
        castCtx?.let { return it }
        return runCatching { CastContext.getSharedInstance(app) }.getOrNull()?.also {
            castCtx = it
            it.sessionManager.addSessionManagerListener(listener, CastSession::class.java)
        }
    }

    private fun playChromecast(d: CastDevice, item: MediaItem) {
        main.post {
            val route = routes[d.extra]
            val cc = sessionCtx()
            if (route == null) {
                message.value = Msg(R.string.cast_failed, "device not found")
                return@post
            }
            if (cc == null) {
                message.value = Msg(R.string.no_play_services)
                return@post
            }
            pending = item
            pendingDevice = d
            val s = cc.sessionManager.currentCastSession
            if (s != null && s.isConnected && selectedRouteId == d.extra) {
                loadPending(s)
            } else {
                selectedRouteId = d.extra
                router?.selectRoute(route)
            }
        }
    }

    private fun loadPending(s: CastSession) {
        val item = pending ?: return
        val dev = pendingDevice ?: return
        pending = null
        val client = s.remoteMediaClient ?: return
        val md = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, item.title)
        }
        val info = MediaInfo.Builder(item.url)
            .setStreamType(if (item.live) MediaInfo.STREAM_TYPE_LIVE else MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(item.mime)
            .setMetadata(md)
            .build()
        client.load(MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build())
        now.value = NowPlaying(dev, item)
    }

    private val listener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(s: CastSession, id: String) = loadPending(s)
        override fun onSessionResumed(s: CastSession, wasSuspended: Boolean) = loadPending(s)
        override fun onSessionEnded(s: CastSession, error: Int) {
            if (now.value?.device?.kind == Kind.CHROMECAST) now.value = null
            selectedRouteId = null
        }

        override fun onSessionStartFailed(s: CastSession, error: Int) {
            message.value = Msg(R.string.cast_failed, "Chromecast error $error")
            selectedRouteId = null
        }

        override fun onSessionStarting(s: CastSession) {}
        override fun onSessionEnding(s: CastSession) {}
        override fun onSessionResuming(s: CastSession, id: String) {}
        override fun onSessionResumeFailed(s: CastSession, error: Int) {}
        override fun onSessionSuspended(s: CastSession, reason: Int) {}
    }
}

# Recon map: Web Video Cast (com.instantbits.cast.webvideo)

Source: public Google Play listing only (no account, no APK, no network capture).
Date: 2026-11-20. Method: clean-room. Features and flows, nothing the app owns.

## Scope
- Platform: Android.
- Slice: the core loop = browse a site, detect its video, cast it to a TV.
- For: the user's own product (free, no ads). Added vs original: screen mirroring with quality presets, glass UI.

## Sources
| source | url | gives |
| --- | --- | --- |
| Play listing | https://play.google.com/store/apps/details?id=com.instantbits.cast.webvideo | feature list, supported devices, free vs premium split, changelog, reviews |

## Core loop
Open a website in the in-app browser -> app detects the page's video stream -> user taps Cast -> picks a TV/receiver -> video plays on the TV; the phone becomes the remote.

## Screens (inferred from the listing text; screenshots had no captions)
| ID | screen | purpose | key components | states |
| --- | --- | --- | --- | --- |
| S01 | Browser | browse sites, detect video | URL bar, WebView, cast button + count | loading, no video, video found |
| S02 | Device picker | choose TV | device list, rescan | scanning, empty, found |
| S03 | Now playing / remote | control playback | play/pause, stop, seek | playing, paused, error |
| S04 | Bookmarks (premium in original) | saved sites | list | empty, filled |
| S05 | History (premium in original) | past videos | list, bulk delete | empty, filled |
| S06 | Local files | cast phone media | picker | empty, selected |
| S07 | Subtitles | detect / pick / OpenSubtitles | list | none, found |
| S08 | Settings | theme, home page | toggles | - |

## Flows
- F01 Cast web video: S01 -> S02 -> S03. Happy path 3 taps after video is playing.
- F02 Cast local media: S06 -> S02 -> S03.
- F03 Revisit: S04/S05 -> S01 -> F01.

## Inferred data model
- Bookmark(title, url) - high confidence (listed feature)
- HistoryEntry(title, url, ts) - high
- Device(id, name, protocol, address) - high (Chromecast, Roku, DLNA, Fire TV, smart TVs)
- MediaItem(url, title, mime) - high
- Subtitle(url, lang) - medium

## Feature matrix
See `features.csv`.

## What cannot / will not be cloned
- Original code, name, logo, copy, store assets.
- DRM streams (Netflix, Disney+ etc.): the original does not play them either ("any HTML5 video the device can decode").
- Their OpenSubtitles integration needs the user's own API key: left as a later step.
- Fire TV / Samsung / LG proprietary protocols: covered only via DLNA.

## Differences chosen on purpose
- Everything the original puts behind premium (bookmarks, history, queue, no ads) is free here.
- No ad SDKs, no trackers. Browser blocks ads and pop-ups.
- NEW: screen mirroring (original has no tab/screen casting) with 4 quality presets.
- NEW: glass UI, black + muted red or blue.

## Size
M. Screens 8, flows 3, entities 4. Hard parts: (1) MPEG-TS live encoder for mirroring, (2) device discovery across Chromecast/DLNA/Roku, (3) video URL detection on arbitrary sites.
